package com.example.andrea.provaprimafacciata;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.AudioManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TimeOverActivity extends AppCompatActivity {

    private Button stopButton;
    private Uri mySuond;
    private Intent myIntent, risposta;
    private PendingIntent pIntent;
    private Notification myNoti;
    private NotificationManager myNotificationManager;
    private AudioManager myAudioManager;
    private Ringtone myRingtone;
    private Uri myUriNotification;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_over);
        //ROTAZIONE SCHERMO BLOCCATA
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        stopButton = (Button) findViewById(R.id.buttonTermina);

        mySuond = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        myIntent = new Intent();
        pIntent = PendingIntent.getActivity(this, 0, myIntent, 0);  //this = context
        myNoti = new Notification.Builder(this)
                .setTicker("TIME OVER")
                .setContentTitle("TIME OVER")
                .setContentText("00:00:00")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(pIntent).getNotification();
        myNoti.flags=Notification.FLAG_AUTO_CANCEL;
        myNotificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        myNotificationManager.notify(0, myNoti);

        try {
            myUriNotification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            myRingtone = RingtoneManager.getRingtone(getApplicationContext(), myUriNotification);
            myRingtone.play();
            //myRingtone.setAudioAttributes();
        } catch (Exception e) {
            e.printStackTrace();
        }


        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*if(myNoti != null) {
                    myNotificationManager.cancelAll();
                    myRingtone.stop();
                }

                risposta.putExtra(getPackageName(), "fatto");
                //Restituisco il codice identificativo dell'activity corrente e la risposta
                setResult(123, risposta);
                finish();*/

                onBackPressed();
            }
        });

    }

    @Override
    public void onBackPressed(){
        risposta = new Intent(this.getApplicationContext(), MainActivity.class);

        if(myNoti != null) {
            myNotificationManager.cancelAll();
            myRingtone.stop();
        }

        risposta.putExtra(getPackageName(), "fatto");
        //Restituisco il codice identificativo dell'activity corrente e la risposta
        setResult(123, risposta);
        finish();
    }

    /*@Override
    public void onResume()
    {

    }*/
}

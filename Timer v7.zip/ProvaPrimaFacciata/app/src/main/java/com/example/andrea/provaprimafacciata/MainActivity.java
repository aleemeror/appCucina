package com.example.andrea.provaprimafacciata;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.NumberPicker;
import android.widget.TextView;

import java.util.concurrent.TimeUnit;


public class MainActivity extends AppCompatActivity
{
    private Button setTime, cancelTime;
    private Button pauseButton, resumeButton, stopButton;
    private TextView myResult;

    private TextView editOre;
    private TextView editMinuti;
    private TextView editSecondi;

    private CountDownTimer cdt = null;

    private int tot = 0;
    private long millis = 0;

    boolean StatoBottoneAttuale=true; //true = "pausa" ; false = "resume"
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //ROTAZIONE SCHERMO BLOCCATA
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        setTime = (Button)findViewById(R.id.setTime);
        cancelTime = (Button)findViewById(R.id.cancel);
        pauseButton = (Button)findViewById(R.id.buttonPause);
        stopButton = (Button)findViewById(R.id.buttonStop);
        resumeButton = (Button)findViewById(R.id.buttonResume);

        editSecondi = (TextView)findViewById(R.id.txtTimerSecond);
        editMinuti = (TextView)findViewById(R.id.txtTimerMinute);
        editOre = (TextView)findViewById(R.id.txtTimerHour);

        myResult = (TextView)findViewById(R.id.risultato);

        final NumberPicker ore = (NumberPicker) findViewById(R.id.npicker_hours);
        ore.setMaxValue(99);
        ore.setMinValue(00);
        ore.setFocusable(true);
        ore.setFocusableInTouchMode(true);


        final NumberPicker minuti = (NumberPicker) findViewById(R.id.npicker_minutes);
        minuti.setMaxValue(59);
        minuti.setMinValue(00);
        minuti.setFocusable(true);
        minuti.setFocusableInTouchMode(true);

        final NumberPicker secondi = (NumberPicker) findViewById(R.id.npicker_seconds);
        secondi.setMaxValue(59);
        secondi.setMinValue(00);
        secondi.setFocusable(true);
        secondi.setFocusableInTouchMode(true);

        /*INTENT PER LA ECONDA ACTIVITY*/
        final Intent secondACT = new Intent(this.getApplicationContext(),TimeOverActivity.class);

        setTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int h = ore.getValue();
                int m = minuti.getValue();
                int s = secondi.getValue();
                tot = s * 1000 + m * 60000 + h * 3600000+ 1000;

                String myH = Integer.toString(h);
                String myM = Integer.toString(m);
                String myS = Integer.toString(s);


                setTime.setClickable(false);

                if (tot != 0) {

                    pauseButton.setVisibility(pauseButton.VISIBLE);
                    resumeButton.setVisibility(resumeButton.GONE);

                    cdt = new CountDownTimer(tot, 1000) {

                        public void onTick(long millisUntilFinished) {
                            millis = millisUntilFinished;
                            String h = String.format("%02d", TimeUnit.MILLISECONDS.toHours(millis));
                            editOre.setText(h);
                            String m = String.format("%02d", TimeUnit.MILLISECONDS.toMinutes(millis) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millis)));
                            editMinuti.setText(m);
                            String s = String.format("%02d", TimeUnit.MILLISECONDS.toSeconds(millis) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis)));
                            editSecondi.setText(s);
                            myResult.setText(Long.toString(millisUntilFinished));
                            if(millisUntilFinished<2000 && millisUntilFinished>1000)
                                millisUntilFinished=2000;
                        }

                        public void onFinish() {
                            editOre.setText("00");
                            editMinuti.setText("00");
                            editSecondi.setText("00");
                            //myResult.setText("done!");

                            startActivityForResult(secondACT, 123);

                            setTime.setClickable(true);
                        }
                    }.start();
                }

                myResult.setText(myH + myM + myS);
            }
        });

        cancelTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(tot!= 0 || millis != 0)
                    setTime.setClickable(true);
                ore.setValue(0);
                minuti.setValue(0);
                secondi.setValue(0);
            }
        });

        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(cdt != null) {
                    cdt.cancel();
                }
                editOre.setText("00");
                editMinuti.setText("00");
                editSecondi.setText("00");
                //myResult.setText("");
                tot = 0;
                millis = 0;

                setTime.setClickable(true);

                pauseButton.setVisibility(pauseButton.VISIBLE);
                resumeButton.setVisibility(resumeButton.GONE);
            }
        });


        pauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(StatoBottoneAttuale)
                {
                    if((tot != 0) || (millis !=0)) {
                        setTime.setClickable(false);
                        //resumeButton.setVisibility(resumeButton.VISIBLE);


                   /* RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams)button.getLayoutParams();
                    params.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
                    params.addRule(RelativeLayout.LEFT_OF, R.id.id_to_be_left_of);

                    button.setLayoutParams(params); //causes layout update
                    */

                        //pauseButton.setVisibility(pauseButton.GONE);
                        if (cdt != null) {
                            cdt.cancel();
                        }
                        String h = String.format("%02d", TimeUnit.MILLISECONDS.toHours(millis));
                        editOre.setText(h);
                        String m = String.format("%02d", TimeUnit.MILLISECONDS.toMinutes(millis) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millis)));
                        editMinuti.setText(m);
                        String s = String.format("%02d", TimeUnit.MILLISECONDS.toSeconds(millis) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis)));
                        editSecondi.setText(s);

                        pauseButton.setText("RESUME");
                    }


                }
                else
                {
                    setTime.setClickable(false);
                    //pauseButton.setVisibility(pauseButton.VISIBLE);
                    //resumeButton.setVisibility(resumeButton.GONE);

                    if (millis != 0) {
                        cdt = new CountDownTimer(millis, 1000) {

                            public void onTick(long millisUntilFinished) {
                                millis = millisUntilFinished;
                                String h = String.format("%02d", TimeUnit.MILLISECONDS.toHours(millis));
                                editOre.setText(h);
                                String m = String.format("%02d", TimeUnit.MILLISECONDS.toMinutes(millis) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millis)));
                                editMinuti.setText(m);
                                String s = String.format("%02d", TimeUnit.MILLISECONDS.toSeconds(millis) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis)));
                                editSecondi.setText(s);
                            }

                            public void onFinish() {
                                editOre.setText("00");
                                editMinuti.setText("00");
                                editSecondi.setText("00");
                                //setTime.setText("done!");
                                startActivityForResult(secondACT, 123);

                                setTime.setClickable(true);
                            }
                        }.start();
                        pauseButton.setText("Pause");
                    }

                }

                StatoBottoneAttuale=!StatoBottoneAttuale;

            }
        });

        /*resumeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setTime.setClickable(false);
                pauseButton.setVisibility(pauseButton.VISIBLE);
                resumeButton.setVisibility(resumeButton.GONE);

                if (millis != 0) {
                    cdt = new CountDownTimer(millis, 1000) {

                        public void onTick(long millisUntilFinished) {
                            millis = millisUntilFinished;
                            String h = String.format("%02d", TimeUnit.MILLISECONDS.toHours(millis));
                            editOre.setText(h);
                            String m = String.format("%02d", TimeUnit.MILLISECONDS.toMinutes(millis) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millis)));
                            editMinuti.setText(m);
                            String s = String.format("%02d", TimeUnit.MILLISECONDS.toSeconds(millis) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis)));
                            editSecondi.setText(s);
                        }

                        public void onFinish() {
                            editOre.setText("00");
                            editMinuti.setText("00");
                            editSecondi.setText("00");
                            //setTime.setText("done!");

                            setTime.setClickable(true);
                        }
                    }.start();
                }
            }
        });*/
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        //Il numero 123 serve a identificare chi ci ha restituito la risposta
        if (requestCode == 123) {
            //Recupero la risposta inviata
            String stringa = data.getExtras().getString(getPackageName());

            myResult.setText("figlio" + stringa);
        }
    }


    //NON FUNZIONA
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        if(keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_HOME)
        {
            //onBackPressed();
            Intent setIntent = new Intent(Intent.ACTION_MAIN);
            setIntent.addCategory(Intent.CATEGORY_HOME);
            setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(setIntent);
        }
        return super.onKeyDown(keyCode, event);
    }


}
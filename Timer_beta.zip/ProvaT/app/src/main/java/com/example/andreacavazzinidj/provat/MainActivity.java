package com.example.andreacavazzinidj.provat;

import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    private TextView myAlert;

    private EditText editOre;
    private EditText editMinuti;
    private EditText editSecondi;

    private Button buttonTest;
    private Button buttonPausa;
    private Button buttonRiprendi;
    private Button arresta;

    private CountDownTimer cdt=null;

    private int tot = 0;
    private long millis = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myAlert = (TextView) findViewById(R.id.alertInput_finish);
        editOre = (EditText) findViewById(R.id.txtTimerHour);
        editMinuti = (EditText) findViewById(R.id.txtTimerMinute);
        editSecondi = (EditText) findViewById(R.id.txtTimerSecond);
        buttonTest= (Button)findViewById(R.id.button01);
        arresta= (Button)findViewById(R.id.button02);
        buttonPausa = (Button)findViewById(R.id.pause);
        buttonRiprendi = (Button)findViewById(R.id.restart);


        buttonTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //sec * 1000 + min * 60000 + h * 3600000
                int h =Integer.parseInt(editOre.getText().toString());
                int m =Integer.parseInt(editMinuti.getText().toString());
                int s =Integer.parseInt(editSecondi.getText().toString());
                tot = s * 1000 + m * 60000 + h * 3600000;

                myAlert.setText("");
                /*if((h > 23) || (m > 59) || (s > 59)) {
                    myAlert.setText("ERROR");
                    editOre.setText("00");
                    editMinuti.setText("00");
                    editSecondi.setText("00");
                }else {*/

                //QUANDO TUTTI I CAMPI SONO A ZERO ALLORA NON POSSO AVVIARE IL TIMER
                if(tot != 0)
                {
                    buttonTest.setClickable(false);

                    editOre.setCursorVisible(false);
                    editSecondi.setCursorVisible(false);
                    editMinuti.setCursorVisible(false);

                    cdt = new CountDownTimer(tot, 1000) {

                        public void onTick(long millisUntilFinished) {
                            millis = millisUntilFinished;
                            String h = String.format("%02d", TimeUnit.MILLISECONDS.toHours(millis));
                            editOre.setText(h);
                            String m = String.format("%02d", TimeUnit.MILLISECONDS.toMinutes(millis) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millis)));
                            editMinuti.setText(m);
                            String s = String.format("%02d", TimeUnit.MILLISECONDS.toSeconds(millis) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis)));
                            editSecondi.setText(s);
                        }

                        public void onFinish() {
                            editOre.setText("00");
                            editMinuti.setText("00");
                            editSecondi.setText("00");
                            myAlert.setText("done!");

                            buttonTest.setClickable(true);

                            editOre.setCursorVisible(true);
                            editSecondi.setCursorVisible(true);
                            editMinuti.setCursorVisible(true);
                        }
                    }.start();
                }
            }
        });

        arresta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(cdt != null) {
                    cdt.cancel();
                }
                editOre.setText("00");
                editMinuti.setText("00");
                editSecondi.setText("00");
                myAlert.setText("");
                tot = 0;
                millis = 0;

                buttonTest.setClickable(true);

                editOre.setCursorVisible(true);
                editSecondi.setCursorVisible(true);
                editMinuti.setCursorVisible(true);

                }
            });

        buttonPausa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonTest.setClickable(false);
                buttonPausa.setVisibility(buttonPausa.GONE);
                buttonRiprendi.setVisibility(buttonRiprendi.VISIBLE);
                if(cdt != null) {
                    cdt.cancel();
                }
                String h = String.format("%02d", TimeUnit.MILLISECONDS.toHours(millis));
                editOre.setText(h);
                String m = String.format("%02d", TimeUnit.MILLISECONDS.toMinutes(millis) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millis)));
                editMinuti.setText(m);
                String s = String.format("%02d", TimeUnit.MILLISECONDS.toSeconds(millis) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis)));
                editSecondi.setText(s);
            }
        });

        buttonRiprendi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonTest.setClickable(false);
                buttonPausa.setVisibility(buttonPausa.VISIBLE);
                buttonRiprendi.setVisibility(buttonRiprendi.GONE);

                if(millis !=0 )
                {
                    cdt = new CountDownTimer(millis, 1000) {

                        public void onTick(long millisUntilFinished) {
                            millis = millisUntilFinished;
                            String h = String.format("%02d", TimeUnit.MILLISECONDS.toHours(millis));
                            editOre.setText(h);
                            String m = String.format("%02d", TimeUnit.MILLISECONDS.toMinutes(millis) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millis)));
                            editMinuti.setText(m);
                            String s = String.format("%02d", TimeUnit.MILLISECONDS.toSeconds(millis) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis)));
                            editSecondi.setText(s);
                        }

                        public void onFinish() {
                            editOre.setText("00");
                            editMinuti.setText("00");
                            editSecondi.setText("00");
                            myAlert.setText("done!");

                            buttonTest.setClickable(true);

                            editOre.setCursorVisible(true);
                            editSecondi.setCursorVisible(true);
                            editMinuti.setCursorVisible(true);
                        }
                    }.start();
                }
            }
        });


    }
}

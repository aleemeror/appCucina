package com.example.studente.appcucinaproject.Cards;

import android.view.View;

/**
 * Created by Mattia on 22/04/2016.
 */
public interface itemClickListener {

    void onItemClick(View v, int pos);
}

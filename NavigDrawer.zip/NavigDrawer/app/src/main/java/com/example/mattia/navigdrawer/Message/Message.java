package com.example.mattia.navigdrawer.Message;

/**
 * Created by studente on 14/03/2016.
 */
public class Message {

    private String msg;
    private String desc;
    private int resId;
    private int descID;


    public Message(String msg, String desc, int resId, int descID) {
        this.msg = msg;
        this.desc = desc;
        this.resId = resId;
        this.descID = descID;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getResId() {
        return resId;
    }

    public void setResId(int resId) {
        this.resId = resId;
    }

    public int getDescID() {
        return descID;
    }

    public void setDescID(int descID) {
        this.descID = descID;
    }

}

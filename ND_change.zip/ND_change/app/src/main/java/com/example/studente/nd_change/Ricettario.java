package com.example.studente.nd_change;

import android.app.Activity;

/**
 * Created by studente on 05/02/2016.
 */
public class Ricettario extends Activity{
}

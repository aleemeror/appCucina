package com.example.andrea.provaprimafacciata;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.NumberPicker;
import android.widget.TextView;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity
{
    private Button setTime, cancelTime;
    private Button pauseButton, resumeButton, stopButton;
    private TextView myResult;

    private TextView editOre;
    private TextView editMinuti;
    private TextView editSecondi;

    //private CountDownTimer cdt = null;

    private Ticker tt = null;

    private int tot = 0;
    private long millis = 0;

    boolean StatoBottoneAttuale=true; //true = "pausa" ; false = "resume"

    private Intent secondACT;
    private EventTimer r;

    boolean timerAttivato = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //ROTAZIONE SCHERMO BLOCCATA
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        setTime = (Button)findViewById(R.id.setTime);
        cancelTime = (Button)findViewById(R.id.cancel);
        pauseButton = (Button)findViewById(R.id.buttonPause);
        stopButton = (Button)findViewById(R.id.buttonStop);
        resumeButton = (Button)findViewById(R.id.buttonResume);

        editSecondi = (TextView)findViewById(R.id.txtTimerSecond);
        editMinuti = (TextView)findViewById(R.id.txtTimerMinute);
        editOre = (TextView)findViewById(R.id.txtTimerHour);

        myResult = (TextView)findViewById(R.id.risultato);

        final NumberPicker ore = (NumberPicker) findViewById(R.id.npicker_hours);
        ore.setMaxValue(99);
        ore.setMinValue(00);
        ore.setFocusable(true);
        ore.setFocusableInTouchMode(true);


        final NumberPicker minuti = (NumberPicker) findViewById(R.id.npicker_minutes);
        minuti.setMaxValue(59);
        minuti.setMinValue(00);
        minuti.setFocusable(true);
        minuti.setFocusableInTouchMode(true);

        final NumberPicker secondi = (NumberPicker) findViewById(R.id.npicker_seconds);
        secondi.setMaxValue(59);
        secondi.setMinValue(00);
        secondi.setFocusable(true);
        secondi.setFocusableInTouchMode(true);

        /*INTENT PER LA ECONDA ACTIVITY*/
        secondACT = new Intent(this.getApplicationContext(),TimeOverActivity.class);

        if(timerAttivato)
            setTime.setClickable(false);
        else
            setTime.setClickable(true);

        setTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setTime.setClickable(false);
                //String myH = Integer.toString(h);
                //String myM = Integer.toString(m);
                //String myS = Integer.toString(s);
                int h = ore.getValue();
                int m = minuti.getValue();
                int s = secondi.getValue();
                tot = s * 1000 + m * 60000 + h * 3600000 + 1000;    //+ 1000 finale a livello estetico


                if (tot != 0) {
                    r = new EventTimer();
                    tt = new Ticker(r, 1000, tot);
                    tt.Start();
                    timerAttivato = true;
                }
            }
        });

        cancelTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!timerAttivato)
                    setTime.setClickable(true);

                ore.setValue(0);
                minuti.setValue(0);
                secondi.setValue(0);
            }
        });

        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(tt != null) {
                    tt.Pause(); //il metodo fa timer.stop()
                }
                editOre.setText("00");
                editMinuti.setText("00");
                editSecondi.setText("00");

                tot = 0;
                millis = 0;

                timerAttivato = false;
                setTime.setClickable(true);

                pauseButton.setVisibility(pauseButton.VISIBLE);
                resumeButton.setVisibility(resumeButton.GONE);
            }
        });


        pauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timerAttivato = true;
                setTime.setClickable(false);

                if(StatoBottoneAttuale)
                {
                    if((tot != 0) || (millis !=0)) {
                        setTime.setClickable(false);

                        if (tt != null) {
                            tt.Pause();
                        }
                        String h = String.format("%02d", TimeUnit.MILLISECONDS.toHours(millis));
                        editOre.setText(h);
                        String m = String.format("%02d", TimeUnit.MILLISECONDS.toMinutes(millis) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millis)));
                        editMinuti.setText(m);
                        String s = String.format("%02d", TimeUnit.MILLISECONDS.toSeconds(millis) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis)));
                        editSecondi.setText(s);

                        pauseButton.setText("RESUME");
                    }
                }
                else
                {
                    setTime.setClickable(false);
                    if (millis != 0) {
                        tt = new Ticker(r, 1000, millis);
                        tt.Start();
                        pauseButton.setText("PAUSE");
                        timerAttivato = true;
                    }
                }
                StatoBottoneAttuale=!StatoBottoneAttuale;
            }
        });
    }

    class  SetTimeTextBox implements  Runnable
    {
        String h,m,s;
        public  SetTimeTextBox(String h,String m,String s)
        {
            this.h=h;
            this.m=m;
            this.s=s;
        }
        @Override
        public void run() {

            editOre.setText(h);
            editMinuti.setText(m);
            editSecondi.setText(s);
        }
    }

    class EventTimer implements Responder
    {

        @Override
        public void Tick(long MillisecRimasti) {

            millis = MillisecRimasti;
            String h = String.format("%02d", TimeUnit.MILLISECONDS.toHours(millis));
            String m = String.format("%02d", TimeUnit.MILLISECONDS.toMinutes(millis) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millis)));
            String s = String.format("%02d", TimeUnit.MILLISECONDS.toSeconds(millis) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis)));
            runOnUiThread(new SetTimeTextBox(h,m,s));
        }

        @Override
        public void End() {
            startActivity(secondACT);
            //startActivityForResult(secondACT, 123);
            runOnUiThread(new SetTimeTextBox("00", "00", "00"));

            //System.exit(0);
            setTime.setClickable(true);
            timerAttivato = false;
        }
    }

}


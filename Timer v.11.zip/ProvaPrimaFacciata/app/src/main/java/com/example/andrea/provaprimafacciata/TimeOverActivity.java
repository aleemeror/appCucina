package com.example.andrea.provaprimafacciata;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

public class TimeOverActivity extends AppCompatActivity {

    private Button stopButton;
    private Uri mySuond;
    private Intent myIntent, risposta;
    private PendingIntent pIntent;
    private Notification myNoti;
    private NotificationManager myNotificationManager;
    private AudioManager myAudioManager;
    private Ringtone myRingtone;
    private Uri myUriNotification;
    private int volume_level;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_over);
        //ROTAZIONE SCHERMO BLOCCATA
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        //ACCENDI SCHERMO QUANDO BLOCCATO
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);

        stopButton = (Button) findViewById(R.id.buttonTermina);

        myAudioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        volume_level = myAudioManager.getStreamVolume(AudioManager.STREAM_RING);

        myAudioManager.setStreamVolume(AudioManager.STREAM_RING, myAudioManager.getStreamMaxVolume(AudioManager.STREAM_RING),0);
        //myAudioManager.setStreamVolume(AudioManager.STREAM_RING,0,0);

        mySuond = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        //myIntent = new Intent(this.getApplicationContext(),TimeOverActivity.class);
        myIntent = new Intent();
        pIntent = PendingIntent.getActivity(getApplicationContext(), 0, myIntent, 0);  //this = context

        myNoti = new Notification.Builder(this)
                .setTicker("TIME OVER")
                .setContentTitle("TIME OVER")
                .setContentText("00:00:00")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(pIntent).getNotification();

        //myNoti.flags=Notification.FLAG_AUTO_CANCEL;
        //myNoti.contentIntent = pIntent;
        myNotificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        //myIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        myNotificationManager.notify(0, myNoti);

        try {
            myUriNotification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            myRingtone = RingtoneManager.getRingtone(getApplicationContext(), myUriNotification);
            myRingtone.play();
        } catch (Exception e) {
            e.printStackTrace();
        }


        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*
                risposta.putExtra(getPackageName(), "fatto");
                //Restituisco il codice identificativo dell'activity corrente e la risposta
                setResult(123, risposta);
                finish();*/

                onBackPressed();
            }
        });

    }

    /*@Override
    public boolean onKeyDown(int keyCode, KeyEvent event)  {
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_HOME) {
            // do something on back.
            return true;
        }

        return super.onKeyDown(keyCode, event);
    }*/

    @Override
    public void onBackPressed(){
        //risposta = new Intent(this.getApplicationContext(), MainActivity.class);

        if(myNoti != null) {
            myNotificationManager.cancelAll();
            myRingtone.stop();
            myAudioManager.setStreamVolume(
                    AudioManager.STREAM_RING,
                    volume_level,
                    0);
        }
        //risposta.putExtra(getPackageName(), "fatto");
        //Restituisco il codice identificativo dell'activity corrente e la risposta
        //setResult(123, risposta);

        finish();
        setResult(Activity.RESULT_OK);
        //System.exit(0);

        return;
    }
}

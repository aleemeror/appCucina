package com.example.andrea.provadoppiointent;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button empty, fulled;
    private TextView ris;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //ROTAZIONE SCHERMO BLOCCATA
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        empty = (Button)findViewById(R.id.buttonEmpty);
        fulled = (Button)findViewById(R.id.buttonFull);
        ris = (TextView)findViewById(R.id.results);

        final Intent secondACT = new Intent(this.getApplicationContext(),EmptyActivity_postFulled.class);

        empty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //startActivity(new Intent(MainActivity.this, EmptyActivity_postFulled.class));
                //startActivity(secondACT);
                startActivityForResult(secondACT, 123);
            }
        });

        fulled.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //startActivity(new Intent(MainActivity.this, ???.class));
            }
        });


    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        //Il numero 123 serve a identificare chi ci ha restituito la risposta
        if (requestCode == 123) {
            //Recupero la risposta inviata
            String stringa = data.getExtras().getString(getPackageName());

            ris.setText("figlio" + stringa);
        }
    }

}

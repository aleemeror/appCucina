package com.example.andrea.provadoppiointent;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;

public class EmptyActivity_postFulled extends Activity {

    private Chronometer chronometer;
    private Button stopButton;
    private Intent risposta = new Intent();
    private Ringtone myRingtone;
    private MediaPlayer myMediaPlayer;
    private AudioManager myAudioManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity_empty_post_fulled);
        //ROTAZIONE SCHERMO BLOCCATA
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        stopButton = (Button) findViewById(R.id.buttonTermina);

        //Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        //myRingtone = RingtoneManager.getRingtone(getApplicationContext(), notification);
        //myMediaPlayer = MediaPlayer.create(getApplicationContext(), notification);

        myMediaPlayer = MediaPlayer.create(getApplicationContext(), RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
        myAudioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        try {
            myMediaPlayer.setVolume((float)(myAudioManager.getStreamVolume(AudioManager.STREAM_NOTIFICATION)),
                    (float)(myAudioManager.getStreamVolume(AudioManager.STREAM_NOTIFICATION)));
        } catch (Exception e) {
            e.printStackTrace();
        }
        //myRingtone.play();
        myMediaPlayer.start();


        //String x = chronometer.getFormat();
        //long y =  chronometer.getBase();


        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                risposta.putExtra(getPackageName(), "fatto");

                //Restituisco il codice identificativo dell'activity corrente e la risposta
                setResult(123, risposta);
                //myRingtone.stop();
                myMediaPlayer.stop();
                finish();
            }
        });
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)  {
        if (Integer.parseInt(android.os.Build.VERSION.SDK) < 5
                && keyCode == KeyEvent.KEYCODE_BACK
                && event.getRepeatCount() == 0) {
            Log.d("CDA", "onKeyDown Called");
            onBackPressed();
        }

        return super.onKeyDown(keyCode, event);
    }

    public void onBackPressed() {
        Log.d("CDA", "onBackPressed Called");
        Intent setIntent = new Intent(Intent.ACTION_MAIN);
        setIntent.addCategory(Intent.CATEGORY_HOME);
        setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(setIntent);

        return;
    }
}


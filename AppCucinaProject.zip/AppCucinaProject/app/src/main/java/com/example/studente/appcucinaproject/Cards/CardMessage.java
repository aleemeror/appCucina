package com.example.studente.appcucinaproject.Cards;

/**
 * Created by Mattia on 22/04/2016.
 */
public class CardMessage {

    private String msg;
    private String desc;
    private int resId;
    private String descID;


    public CardMessage(String msg, String desc, int resId, String descID) {
        this.msg = msg;
        this.desc = desc;
        this.resId = resId;
        this.descID = descID;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getResId() {
        return resId;
    }

    public void setResId(int resId) {
        this.resId = resId;
    }

    public String getDescID() {
        return descID;
    }

    public void setDescID(String descID) {
        this.descID = descID;
    }
}
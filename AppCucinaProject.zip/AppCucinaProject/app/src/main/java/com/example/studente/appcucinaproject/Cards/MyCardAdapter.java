package com.example.studente.appcucinaproject.Cards;

/**
 * Created by Mattia on 22/04/2016.
 */
import android.content.Context;
import android.content.Intent;
import android.os.Message;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.studente.appcucinaproject.R;
import com.example.studente.appcucinaproject.Ricettario.Ricetta;

import java.util.List;



public class MyCardAdapter extends RecyclerView.Adapter<MyCardAdapter.ViewHolder>{

    private String[] mDataset;
    Context c;

    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        public CardView mCardView;
        public TextView mTextView;
        public ImageView mImageView;
        private itemClickListener itemCListener;




        public ViewHolder(View v) {
            super(v);

            mCardView = (CardView) v.findViewById(R.id.cv);
            mTextView = (TextView) v.findViewById(R.id.txtMesg);
            mImageView = (ImageView) v.findViewById(R.id.imgMsg);

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            this.itemCListener.onItemClick(v,getLayoutPosition());
        }

        public void setItemClickListener(itemClickListener ic)
        {
            this.itemCListener=ic;

        }


    }

    // Provide a suitable constructor (depends on the kind of dataset)
    public MyCardAdapter(String[] myDataset) {
        mDataset = myDataset;
    }

    // Create new views (invoked by the layout manager)
    @Override
    public MyCardAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,
                                                     int viewType) {
        // create a new view
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_card, parent, false);
        // set the view's size, margins, paddings and layout parameters
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.mTextView.setText(mDataset[position]);

        //BIND DATA
       /* holder.nameTxt.setText(players[position]);
        holder.posTxt.setText(positions[position]);
        holder.img.setImageResource(images[position]);*/

        //WHEN ITEM IS CLICKED
        holder.setItemClickListener(new itemClickListener() {
            @Override
            public void onItemClick(View v, int pos) {

                //INTENT OBJ
                Intent i=new Intent(c,Ricetta.class);

                //ADD DATA TO OUR INTENT
                /*i.putExtra("Name",players[position]);
                i.putExtra("Position",positions[position]);
                i.putExtra("Image",images[position]);*/

                //START DETAIL ACTIVITY
                c.startActivity(new Intent(c,Ricetta.class));

            }
        });


    }

    @Override
    public int getItemCount() {
        return mDataset.length;
    }
}
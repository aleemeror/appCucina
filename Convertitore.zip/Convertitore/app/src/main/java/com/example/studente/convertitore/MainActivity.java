package com.example.studente.convertitore;

import android.graphics.Color;
import android.graphics.drawable.PaintDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.math.BigDecimal;

public class MainActivity extends AppCompatActivity {

    private Button button1;
    private Button button2;
    private Button button3;
    private Button button4;
    private Button button5;
    private Button button6;
    private Button button7;
    private Button button8;
    private Button button9;
    private Button button0;
    private Button buttonc;
    private Button buttonpunto;
    private Button buttonpeso;
    private Button buttonacqua;
    private Button buttongradi;
    private TextView unitàdac,unitàc;

    private EditText number,number2;

    String numero1="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button1=(Button)findViewById(R.id.button1);
        button2=(Button)findViewById(R.id.button2);
        button3=(Button)findViewById(R.id.button3);
        button4=(Button)findViewById(R.id.button4);
        button5=(Button)findViewById(R.id.button5);
        button6=(Button)findViewById(R.id.button6);
        button7=(Button)findViewById(R.id.button7);
        button8=(Button)findViewById(R.id.button8);
        button9=(Button)findViewById(R.id.button9);
        button0=(Button)findViewById(R.id.button0);
        buttonpunto=(Button)findViewById(R.id.buttonpunto);
        buttonc=(Button)findViewById(R.id.buttonC);
        buttonpeso=(Button)findViewById(R.id.buttonpeso);
        buttonacqua=(Button)findViewById(R.id.buttonacqua);
        buttongradi=(Button)findViewById(R.id.buttongradi);
        number=(EditText)findViewById(R.id.editText);
        number2=(EditText)findViewById(R.id.editText2);
        numero1 = number.getText().toString();
        unitàdac=(TextView)findViewById(R.id.textView);
        unitàc=(TextView)findViewById(R.id.textView2);

        button0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    numero1 += "0";
                    number.setText(numero1);
            }
        });

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numero1 += "1";
                number.setText(numero1);
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numero1 += "2";
                number.setText(numero1);
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numero1 += "3";
                number.setText(numero1);
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numero1 += "4";
                number.setText(numero1);
            }
        });

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numero1 += "5";
                number.setText(numero1);
            }
        });

        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numero1 += "6";
                number.setText(numero1);
            }
        });

        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numero1 += "7";
                number.setText(numero1);
            }
        });

        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numero1 += "8";
                number.setText(numero1);
            }
        });

        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numero1 += "9";
                number.setText(numero1);
            }
        });

        buttonpunto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numero1 += ".";
                number.setText(numero1);
            }
        });

        buttonpeso.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double numeroUno = 0.0;
                Double numeroDue = 0.0;
                try {
                    numeroUno = Double.parseDouble(numero1);
                    numeroDue = numeroUno * 28.3495;
                    BigDecimal bd = new BigDecimal(numeroDue);
                    bd = bd.setScale(2,BigDecimal.ROUND_HALF_UP);
                    numeroDue = bd.doubleValue();
                    number2.setText(Double.toString(numeroDue));
                    unitàdac.setText("oz");
                    unitàc.setText("g");
                } catch (Exception E) {
                    number.setText("ERRORE");
                }
            }
        });

        buttonacqua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double numeroUno = 0.0;
                Double numeroDue = 0.0;
                try {
                    numeroUno = Double.parseDouble(numero1);
                    numeroDue = numeroUno * 29.5753;
                    BigDecimal bd = new BigDecimal(numeroDue);
                    bd = bd.setScale(2, BigDecimal.ROUND_HALF_UP);
                    numeroDue = bd.doubleValue();
                    number2.setText(Double.toString(numeroDue));
                    unitàdac.setText("fl oz");
                    unitàc.setText("ml");
                } catch (Exception E) {
                    number.setText("ERRORE");
                }
            }
        });

        buttongradi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double numeroUno = 0.0;
                Double numeroDue = 0.0;
                try {
                    numeroUno = Double.parseDouble(numero1);
                    numeroDue = (numeroUno-32) / 1.8;
                    BigDecimal bd = new BigDecimal(numeroDue);
                    bd = bd.setScale(2, BigDecimal.ROUND_HALF_UP);
                    numeroDue = bd.doubleValue();
                    number2.setText(Double.toString(numeroDue));
                    unitàdac.setText("°F");
                    unitàc.setText("°C");
                } catch (Exception E) {
                    number.setText("ERRORE");
                }
            }
        });

        buttonc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numero1 = "";
                number.setText(numero1);
                number2.setText("");
            }
        });
    }
}

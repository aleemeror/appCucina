package com.example.studente.appcucinaproject.Timer;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.NumberPicker;
import android.widget.TextView;

import com.example.studente.appcucinaproject.CalcolaTeglia.CalcolaTeglia;
import com.example.studente.appcucinaproject.Calcolatrice.Calcolatrice;
import com.example.studente.appcucinaproject.Home;
import com.example.studente.appcucinaproject.R;
import com.example.studente.appcucinaproject.RicercaAvanzata.RicercaAV;
import com.example.studente.appcucinaproject.Ricettario.Ricettario;
import com.example.studente.appcucinaproject.Spesa.Spesa;

import java.util.concurrent.TimeUnit;

public class Timer extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {


    private Button setTime, cancelTime;
    private Button pauseButton, resumeButton, stopButton;
    private TextView myResult;

    private TextView editOre;
    private TextView editMinuti;
    private TextView editSecondi;

    private Ticker tt = null;

    private int tot = 0;
    private long millis = 0;

    boolean StatoBottoneAttuale=true; //true = "pausa" ; false = "resume"

    private Intent secondACT;
    private EventTimer r;

    boolean timerAttivato = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timer);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        setTitle("Timer");

        //ROTAZIONE SCHERMO BLOCCATA
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        setTime = (Button)findViewById(R.id.setTime);
        cancelTime = (Button)findViewById(R.id.cancel);
        pauseButton = (Button)findViewById(R.id.buttonPause);
        stopButton = (Button)findViewById(R.id.buttonStop);
        resumeButton = (Button)findViewById(R.id.buttonResume);

        editSecondi = (TextView)findViewById(R.id.txtTimerSecond);
        editMinuti = (TextView)findViewById(R.id.txtTimerMinute);
        editOre = (TextView)findViewById(R.id.txtTimerHour);

        myResult = (TextView)findViewById(R.id.risultato);

        final NumberPicker ore = (NumberPicker) findViewById(R.id.npicker_hours);
        ore.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
        ore.setMaxValue(99);
        ore.setMinValue(00);
        ore.setFocusable(true);
        ore.setFocusableInTouchMode(true);


        final NumberPicker minuti = (NumberPicker) findViewById(R.id.npicker_minutes);
        minuti.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
        minuti.setMaxValue(59);
        minuti.setMinValue(00);
        minuti.setFocusable(true);
        minuti.setFocusableInTouchMode(true);

        final NumberPicker secondi = (NumberPicker) findViewById(R.id.npicker_seconds);
        secondi.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
        secondi.setMaxValue(59);
        secondi.setMinValue(00);
        secondi.setFocusable(true);
        secondi.setFocusableInTouchMode(true);

        ore.setValue(0);
        minuti.setValue(0);
        secondi.setValue(0);

        /*INTENT PER LA ECONDA ACTIVITY*/
        secondACT = new Intent(this.getApplicationContext(),TimerOverActivity.class);

        if(timerAttivato)
            setTime.setClickable(false);
        else
            setTime.setClickable(true);

        setTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setTime.setClickable(false);
                //String myH = Integer.toString(h);
                //String myM = Integer.toString(m);
                //String myS = Integer.toString(s);
                int h = ore.getValue();
                int m = minuti.getValue();
                int s = secondi.getValue();
                tot = s * 1000 + m * 60000 + h * 3600000 + 1000;    //+ 1000 finale a livello estetico


                if (tot != 0) {
                    r = new EventTimer();
                    tt = new Ticker(r, 1000, tot);
                    tt.Start();
                    timerAttivato = true;

                    ore.setValue(0);
                    minuti.setValue(0);
                    secondi.setValue(0);
                }
            }
        });

        cancelTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!timerAttivato)
                    setTime.setClickable(true);

                ore.setValue(0);
                minuti.setValue(0);
                secondi.setValue(0);
            }
        });

        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tt != null) {
                    tt.Pause(); //il metodo fa timer.stop()
                }
                editOre.setText("00");
                editMinuti.setText("00");
                editSecondi.setText("00");

                tot = 0;
                millis = 0;

                timerAttivato = false;
                setTime.setClickable(true);

                pauseButton.setVisibility(pauseButton.VISIBLE);
                resumeButton.setVisibility(resumeButton.GONE);

                ore.setValue(0);
                minuti.setValue(0);
                secondi.setValue(0);
            }
        });


        pauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timerAttivato = true;
                setTime.setClickable(false);

                if(StatoBottoneAttuale)
                {
                    if((tot != 0) || (millis !=0)) {
                        setTime.setClickable(false);

                        if (tt != null) {
                            tt.Pause();
                        }
                        String h = String.format("%02d", TimeUnit.MILLISECONDS.toHours(millis));
                        editOre.setText(h);
                        String m = String.format("%02d", TimeUnit.MILLISECONDS.toMinutes(millis) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millis)));
                        editMinuti.setText(m);
                        String s = String.format("%02d", TimeUnit.MILLISECONDS.toSeconds(millis) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis)));
                        editSecondi.setText(s);

                        pauseButton.setText("RESUME");
                    }
                }
                else
                {
                    setTime.setClickable(false);
                    if (millis != 0) {
                        tt = new Ticker(r, 1000, millis);
                        tt.Start();
                        pauseButton.setText("PAUSE");
                        timerAttivato = true;

                        ore.setValue(0);
                        minuti.setValue(0);
                        secondi.setValue(0);
                    }
                }
                StatoBottoneAttuale=!StatoBottoneAttuale;
            }
        });
    }

    class  SetTimeTextBox implements  Runnable
    {
        String h,m,s;
        public  SetTimeTextBox(String h,String m,String s)
        {
            this.h=h;
            this.m=m;
            this.s=s;
        }
        @Override
        public void run() {

            editOre.setText(h);
            editMinuti.setText(m);
            editSecondi.setText(s);
        }
    }

    class EventTimer implements Responder
    {

        @Override
        public void Tick(long MillisecRimasti) {

            millis = MillisecRimasti;
            String h = String.format("%02d", TimeUnit.MILLISECONDS.toHours(millis));
            String m = String.format("%02d", TimeUnit.MILLISECONDS.toMinutes(millis) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millis)));
            String s = String.format("%02d", TimeUnit.MILLISECONDS.toSeconds(millis) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis)));
            runOnUiThread(new SetTimeTextBox(h,m,s));
        }

        @Override
        public void End() {
            startActivity(secondACT);
            //startActivityForResult(secondACT, 123);
            runOnUiThread(new SetTimeTextBox("00", "00", "00"));

            //System.exit(0);
            setTime.setClickable(true);
            timerAttivato = false;
        }

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.timer, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            startActivity(new Intent(this, Home.class));
        } else if (id == R.id.nav_ricettario) {

            startActivity(new Intent(this, Ricettario.class));

        } else if (id == R.id.nav_ricerca) {
            startActivity(new Intent(this, RicercaAV.class));

        } else if (id == R.id.nav_spesa) {
            startActivity(new Intent(this, Spesa.class));

        } else if (id == R.id.nav_calcolatrice) {
            startActivity(new Intent(this, Calcolatrice.class));

        } else if (id == R.id.nav_timer) {
            startActivity(new Intent(this, Timer.class));
        }
        else if (id == R.id.nav_calcolateglia) {
            startActivity(new Intent(this, CalcolaTeglia.class));
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}

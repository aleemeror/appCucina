package com.example.studente.appcucinaproject.Ricetta;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.studente.appcucinaproject.R;

public class Ricetta extends AppCompatActivity {
    ImageView imageView;
    TextView txtname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.ricetta_act);

        imageView = (ImageView) findViewById(R.id.d_ricetta_image);
        txtname = (TextView) findViewById(R.id.d_ricetta_title);


        //prendo le info dall'intent
        imageView.setImageResource(getIntent().getIntExtra("img_id",00));
        txtname.setText("Name:"+ getIntent().getStringExtra("name"));

        setTitle(getIntent().getStringExtra("name"));

    }
}

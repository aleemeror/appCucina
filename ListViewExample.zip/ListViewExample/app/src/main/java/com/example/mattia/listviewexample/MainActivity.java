package com.example.mattia.listviewexample;

import android.app.Activity;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.*;

public class MainActivity extends Activity {

    String[] foods;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        foods = new String[]{"Bacon", "Ham", "Tuna", "Candy", "Meatball", "Potato"};
        ListAdapter myAdapter = new CustomAdapter(this,foods);
        ListView myListView = (ListView) findViewById(R.id.listView);
        myListView.setAdapter(myAdapter);

        myListView.setOnItemClickListener(
                new AdapterView.OnItemClickListener(){
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {  // da info riguardo a quale item della lista è stato cliccato
                        String food = String.valueOf(parent.getItemAtPosition(position));   //converto il valore corrispondente dell'item cliccato
                        Toast.makeText(MainActivity.this,food,Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

}

package com.example.mattia.listviewexample;

import android.content.Context;
import android.view.*;
import android.widget.*;

class CustomAdapter extends ArrayAdapter<String>{       //classe che fa da adattatore, prendendo un array e convertendolo nella custom_row creata che vogliamo.


    public CustomAdapter(Context context, String[] foods) {       //constructor
        super(context,R.layout.custom_row,foods);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater myInflater= LayoutInflater.from(getContext());
        View customview = myInflater.inflate(R.layout.custom_row, parent, false);
        String singleTextItem = getItem(position);
        TextView myText = (TextView) customview.findViewById(R.id.titleText);
        ImageView myImg = (ImageView) customview.findViewById(R.id.imageView);

        myText.setText(singleTextItem);
        myImg.setImageResource(R.mipmap.ic_image1);

        return customview;
    }
}
